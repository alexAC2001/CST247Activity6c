﻿INSERT INTO dbo.users (USERNAME, PASSWORD) VALUES ('Bob', 'Password456');
SELECT*FROM dbo.users