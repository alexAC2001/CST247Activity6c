﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RegisterLoginAct2.Models;
using RegisterLoginAct2.Utility;
using System;

namespace RegisterLoginAct2.Controllers
{
    internal class LogActionFilterAttribute : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
            // Get the user variable

            // Context has lots of info at this very moment
            // Must put a cast of (Controller) to tell it that it is a controlle object
            // Model is assigned to UserModel, so UserModel must be casted (  ).
            UserModel user = (UserModel)((Controller)context.Controller).ViewData.Model; // Get the LoginController using the .Controller

            MyLogger.GetInstance().Info("Leaving the ProcessLogin method");
            MyLogger.GetInstance().Info("User that logged in: " + user.toString());

        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            MyLogger.GetInstance().Info("Entering the ProcessLogin method");
        }
    }
}