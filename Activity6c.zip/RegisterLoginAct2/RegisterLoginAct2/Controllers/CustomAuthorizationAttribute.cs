﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace RegisterLoginAct2.Controllers
{
    internal class CustomAuthorizationAttribute : Attribute, IAuthorizationFilter  // From MVC filters library
    {
        public void OnAuthorization(AuthorizationFilterContext context) // From IAuthorizationFilter interface
        {
            string userName = context.HttpContext.Session.GetString("username");

            // see if username was captured or retrieved
            if (userName == null)
            {
                context.Result = new RedirectResult("/login"); // Send to some other page if not authorized
            }
            else
            {
                // do nothing. let the filter pass the request through.
            }
            
        }
    }
}