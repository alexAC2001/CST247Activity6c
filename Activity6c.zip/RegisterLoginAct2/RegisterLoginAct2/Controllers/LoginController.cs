﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NLog;
using RegisterLoginAct2.Models;
using RegisterLoginAct2.Services;
using RegisterLoginAct2.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegisterLoginAct2.Controllers
{
    public class LoginController : Controller
    {
        // We no don't have to declare this item since we have a singleton in the MyLogger file
        //private static Logger logger = LogManager.GetLogger("RegisterLoginAppRule"); // now it knows where it will log to

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        [CustomAuthorization]
        public IActionResult PrivateSectionMustBeLoggedIn()
        {
            return Content("I am a protected method if the proper attribute is applied to me.");
        }

        [LogActionFilter]
        public IActionResult ProcessLogin(UserModel user)
        {
            //MyLogger.GetInstance().Info("Processing a login attempt");
            //MyLogger.GetInstance().Info(user.toString()); // from the UserModel

            SecurityService securityService = new SecurityService();

            if (securityService.IsValid(user))
            {
                HttpContext.Session.SetString("username", user.UserName);
                //MyLogger.GetInstance().Info("Login Success");
                return View("LoginSuccess", user);
            }
            else
            {
                HttpContext.Session.Remove("username"); // Remove the session
                //MyLogger.GetInstance().Warning("Login failure");
                return View("LoginFailure", user);
            }
               
        }
    }
}
